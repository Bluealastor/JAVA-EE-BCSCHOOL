package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.query.Query;

import configuration.HibernateUtil;
import entity.Corso;

public class CorsoDaoImpl implements InterfacciaDao<Corso> {

	@Override
	public List<Corso> findAll() {
		List<Corso> CorsoLista = new ArrayList<>();
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();

			CorsoLista = session.createQuery("FROM Corso", Corso.class).list();
			
			for(Corso corso: CorsoLista) {
				System.out.println(corso);
			}
			
			
		}catch(HibernateException e) {
			System.out.println("Problema Hibernate GetAll CorsoLista");
			e.printStackTrace();
		}catch(Exception e) {
			System.out.println("Problema generico per la GettAll CorsoLista");
			e.printStackTrace();
		}
		
		
		return CorsoLista;
	}

	@Override
	public Corso findOne(int id) {
		Corso corso = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Corso> query = session.createQuery("SELECT c FROM Corso c WHERE c.id = :id");
			query.setParameter("id", id);
			corso = query.getSingleResult();
			System.out.println(corso);
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
			
		return corso;
	}

	@Override
	public void insertMany(List<Corso> tipo) {
		Transaction transaction = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			//creiamo il forEach per salvare i dati
			for(Corso corso: tipo) {
				session.save(corso);
			}
			// diamo il commit per il salvataggio nel DB
			transaction.commit();
			
			session.close();
		
		}catch(ConstraintViolationException ConstraintViolationException) {
			System.out.println("Valore di chiave duplicata in Autori");
			ConstraintViolationException.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
		}
		catch(HibernateException e) {
			System.out.println("Problema Hibernate GetAll Autori");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        };
		}catch(Exception e) {
			System.out.println("Problema generico per la GettAll Autori");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
	        
		
		}
	}

}

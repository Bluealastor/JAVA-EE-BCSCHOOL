package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.query.Query;

import configuration.HibernateUtil;

import entity.Studente;

public class StudenteDaoImpl implements InterfacciaDao<Studente>{

	@Override
	public List<Studente> findAll() {
		List<Studente> studenteLista = new ArrayList<>();
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();

			studenteLista = session.createQuery("FROM Studente", Studente.class).list();
			
			for(Studente studente: studenteLista) {
				System.out.println(studente);
			}
			
			
		}catch(HibernateException e) {
			System.out.println("Problema Hibernate GetAll Automobile");
			e.printStackTrace();
		}catch(Exception e) {
			System.out.println("Problema generico per la GettAll Automobile");
			e.printStackTrace();
		}
		
		
		return studenteLista;
	}

	@Override
	public Studente findOne(int id) {
		Studente studente = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Studente> query = session.createQuery("SELECT s FROM Studente s WHERE s.id = :id");
			query.setParameter("id", id);
			studente = query.getSingleResult();
			System.out.println(studente);
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Studente");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Studente");
				e.printStackTrace();
			}
			
		return studente;
	}

	@Override
	public void insertMany(List<Studente> listaStudente) {
		Transaction transaction = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			//creiamo il forEach per salvare i dati
			for(Studente studente: listaStudente) {
				session.save(studente);
			}
			// diamo il commit per il salvataggio nel DB
			transaction.commit();
			
			session.close();
		
		}catch(ConstraintViolationException ConstraintViolationException) {
			System.out.println("Valore di chiave duplicata in Autori");
			ConstraintViolationException.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
		}
		catch(HibernateException e) {
			System.out.println("Problema Hibernate GetAll Autori");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        };
		}catch(Exception e) {
			System.out.println("Problema generico per la GettAll Autori");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
	        
		
		}
		
	}

}

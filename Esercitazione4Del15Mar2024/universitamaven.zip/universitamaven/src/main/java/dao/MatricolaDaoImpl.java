package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.query.Query;

import configuration.HibernateUtil;
import entity.Matricola;

public class MatricolaDaoImpl implements InterfacciaDao<Matricola> {

	@Override
	public List<Matricola> findAll() {
		List<Matricola> matricolaLista = new ArrayList<>();
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();

			 matricolaLista = session.createQuery("FROM Matricola", Matricola.class).list();
			
			for(Matricola matricola:  matricolaLista) {
				System.out.println(matricola);
			}
			
			
		}catch(HibernateException e) {
			System.out.println("Problema Hibernate GetAll CorsoLista");
			e.printStackTrace();
		}catch(Exception e) {
			System.out.println("Problema generico per la GettAll CorsoLista");
			e.printStackTrace();
		}
		
		
		return matricolaLista;
	}

	@Override
	public Matricola findOne(int id) {
		Matricola matricola = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Matricola> query = session.createQuery("SELECT m FROM Matricola m WHERE m.id = :id");
			query.setParameter("id", id);
			matricola = query.getSingleResult();
			System.out.println(matricola);
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
			
		return matricola;
	}

	@Override
	public void insertMany(List<Matricola> tipo) {
		Transaction transaction = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			//creiamo il forEach per salvare i dati
			for(Matricola matricola: tipo) {
				session.save(matricola);
			}
			// diamo il commit per il salvataggio nel DB
			transaction.commit();
			
			session.close();
		
		}catch(ConstraintViolationException ConstraintViolationException) {
			System.out.println("Valore di chiave duplicata in Matricola");
			ConstraintViolationException.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
		}
		catch(HibernateException e) {
			System.out.println("Problema Hibernate INSERT Matricola");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        };
		}catch(Exception e) {
			System.out.println("Problema generico per la INSERT Matricola");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
	        
		
		}
		
	}



}

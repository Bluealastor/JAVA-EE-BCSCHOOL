package main;

import java.util.ArrayList;
import java.util.List;

import dao.InterfacciaDao;
import dao.StudenteDaoImpl;
import entity.Studente;

public class Main {

	public static void main(String[] args) {
		InterfacciaDao<Studente> studente = new StudenteDaoImpl();
		List<Studente> listaStudenti = new ArrayList<>();
//		listaStudenti.add(new Studente("Mario","Rossi"));
//		listaStudenti.add(new Studente("Giorgio","Verdi"));
		
//		studente.insertMany(listaStudenti);
//		studente.findAll();
//		studente.findOne(1);
		
	}
}

package main;

import dao.InterfacciaDao;
import entity.Ferie;

import java.util.ArrayList;
import java.util.List;

import dao.FerieDao;

public class Main {
	
	public static void main(String[] args) {
		
		InterfacciaDao<Ferie> ferie = new FerieDao();
		List<Ferie> listaFerie = new ArrayList<>();
		listaFerie.add(new Ferie(1,"cde","cde","cde","cde","cde","cde","cde","cde"));
		
		
		ferie.insertMany(listaFerie);
		
	}

}

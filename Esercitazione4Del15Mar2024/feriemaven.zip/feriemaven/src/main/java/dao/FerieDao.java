package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

import configuration.HibernateUtil;
import entity.Ferie;

public class FerieDao implements InterfacciaDao<Ferie>{


	@Override
	public void insertMany(List<Ferie> listaFerie) {
		Transaction transaction = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			//creiamo il forEach per salvare i dati
			for(Ferie ferie: listaFerie) {
				session.save(ferie);
			}
			// diamo il commit per il salvataggio nel DB
			transaction.commit();
			
			session.close();
		
		}catch(ConstraintViolationException ConstraintViolationException) {
			System.out.println("Valore di chiave duplicata in Autori");
			ConstraintViolationException.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
		}
		catch(HibernateException e) {
			System.out.println("Problema Hibernate GetAll Autori");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        };
		}catch(Exception e) {
			System.out.println("Problema generico per la GettAll Autori");
			e.printStackTrace();
			// INSERIRE IL ROLLBACK SE CI SONO PROBLEMI
	        if (transaction != null) {
	            transaction.rollback(); // Rollback della transazione in caso di errore
	        }
		}
	}
	
	

	
	
	
	
	

}

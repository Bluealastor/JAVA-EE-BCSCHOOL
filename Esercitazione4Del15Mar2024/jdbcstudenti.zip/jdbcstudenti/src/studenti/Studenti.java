package studenti;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class Studenti {

	public static void main(String[] args) {

//		aggiungiStudente("123","Mario","Rossi",25,"1990-12-20","ingegreria",4);
//		getStudentiAll();
		findOneStudente("123");
		deleteOneStudente("231");
		deleteAll();
	}

	/*
	 * INIZIO SET Studente
	 * 
	 */

	public static void aggiungiStudente(String matricola, String nome, String cognome, int eta, String dataDiNascita,
			String nomeCorso, int nEsami) {
		Connection conn = null;
		PreparedStatement stmt = null;
// 		Standard per il connector della libreria "jdbc:mysql://URL del database/NOME DATABASE"
		String url = "jdbc:mysql://localhost:3306/studenti";
		String username = "root";
		String password = "";

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.prepareStatement("INSERT INTO studenti VALUES(?,?,?,?,?,?,?)");

			stmt.setString(1, matricola);
			stmt.setString(2, nome);
			stmt.setString(3, cognome);
			stmt.setInt(4, eta);
			stmt.setString(5, dataDiNascita);
			stmt.setString(6, nomeCorso);
			stmt.setInt(7, nEsami);

			stmt.execute();

		} catch (ClassNotFoundException e) {
			System.out.println("Classe non trovata");
			e.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Eccezzione specifica di sql");
			sql.printStackTrace();
		} catch (Exception e) {
			System.out.println("Eccezione generica");
		} finally {

			if (stmt != null) {
				try {
					stmt.close();
					stmt = null;
				} catch (SQLException e) {
					System.out.println("Errore di chiusura Statement");
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
					conn = null;
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura Connection");
					e.printStackTrace();
				}
			}
		}

	}

	/*
	 * FINE SET Studente
	 * 
	 */

	/*
	 * INIZIO GET ALL Studente
	 * 
	 */

	public static void getStudentiAll() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		// percorso mysql:porta/nomeDatabase
		String url = "jdbc:mysql://localhost:3306/studenti";
		String username = "root";
		String password = "";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			conn = DriverManager.getConnection(url, username, password);
			stmt = conn.createStatement();

			rs = stmt.executeQuery("SELECT * FROM studenti");

			while (rs.next()) {
				System.out.println("Matricola: " + rs.getString(1) + " Nome Studente: " + rs.getString(2)
						+ " Cognome studente: " + rs.getString(3) + " età: " + rs.getInt(4) + "Data Di Nascita "
						+ rs.getDate(5) + "Nome Corso: " + rs.getString(6) + "N esami" + rs.getInt(7));
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Classe non trovata");
			e.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Eccezzione specifica di sql");
			sql.printStackTrace();
		} catch (Exception e) {
			System.out.println("Eccezione generica");
		} finally {

			// CHIUSURA RESULTsET
			if (rs != null) {
				try {
					rs.close();
					rs = null;
					System.out.println("chiusura del ResultSet");
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura del ResultSet");
					e.printStackTrace();
				}
			}

			// Chiusura dello Statement
			if (stmt != null) {
				try {
					stmt.close();
					stmt = null;
					System.out.println("chiusura Statement");
				} catch (SQLException e) {
					System.out.println("Errore di chiusura Statement");
					e.printStackTrace();
				}
			}
			// Chiusura dell connection
			if (conn != null) {
				try {
					conn.close();
					conn = null;
					System.out.println("chiusura Connection");
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura Connection");
					e.printStackTrace();
				}
			}

		}

	}

	/*
	 * FINE GET ALL Studente
	 * 
	 */

	/*
	 * INIZIO GET ONE Studente
	 * 
	 */

	public static void findOneStudente(String id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		String url = "jdbc:mysql://localhost:3306/studenti";
		String username = "root";
		String password = "";

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.prepareStatement("SELECT * FROM studenti WHERE matricola LIKE '%" + id + "%'");
			rs = stmt.executeQuery();

			if (rs.next()) {
				System.out.println("Matricola: " + rs.getString(1) + " Nome Studente: " + rs.getString(2)
						+ " Cognome studente: " + rs.getString(3) + " età: " + rs.getInt(4) + "Data Di Nascita "
						+ rs.getDate(5) + "Nome Corso: " + rs.getString(6) + "N esami" + rs.getInt(7));
			} else {
				System.out.println("Nessun risultato trovato per la matricola: " + id);
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Classe non trovata");
			e.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Eccezzione specifica di sql");
			sql.printStackTrace();
		} catch (Exception e) {
			System.out.println("Eccezione generica");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
					System.out.println("chiusura del ResultSet");
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura del ResultSet");
					e.printStackTrace();
				}
			}

			// Chiusura dello Statement
			if (stmt != null) {
				try {
					stmt.close();
					stmt = null;
					System.out.println("chiusura Statement");
				} catch (SQLException e) {
					System.out.println("Errore di chiusura Statement");
					e.printStackTrace();
				}
			}
			// Chiusura dell connection
			if (conn != null) {
				try {
					conn.close();
					conn = null;
					System.out.println("chiusura Connection");
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura Connection");
					e.printStackTrace();
				}
			}

		}

	}

	public static void deleteOneStudente(String id) {
		Connection conn = null;
		PreparedStatement stmt = null;

		String url = "jdbc:mysql://localhost:3306/studenti";
		String username = "root";
		String password = "";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, username, password);

			String deleteQuery = "DELETE FROM studenti WHERE matricola = ?";

			stmt = conn.prepareStatement(deleteQuery);

			stmt.setString(1, id);

			stmt.executeUpdate();

		} catch (ClassNotFoundException e) {
			System.out.println("Classe non trovata");
			e.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Eccezione specifica di SQL");
			sql.printStackTrace();
		} catch (Exception e) {
			System.out.println("Eccezione generica");
			e.printStackTrace();
		} finally {

			if (stmt != null) {
				try {
					stmt.close();
					stmt = null;
				} catch (SQLException e) {
					System.out.println("Errore di chiusura Statement");
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
					conn = null;
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura Connection");
					e.printStackTrace();
				}

			}
		}
	}

	public static void deleteAll() {

		Connection conn = null;
		Statement stmt = null;

		String url = "jdbc:mysql://localhost:3306/studenti";
		String username = "root";
		String password = "";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, username, password);

			stmt = conn.createStatement();

			String deleteQuery = "DELETE FROM studenti";

			stmt.executeUpdate(deleteQuery);

		} catch (ClassNotFoundException e) {
			System.out.println("Classe non trovata");
			e.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Eccezione specifica di SQL");
			sql.printStackTrace();
		} catch (Exception e) {
			System.out.println("Eccezione generica");
			e.printStackTrace();
		} finally {
			// Chiusura dello Statement
			if (stmt != null) {
				try {
					stmt.close();
					stmt = null;
				} catch (SQLException e) {
					System.out.println("Errore di chiusura Statement");
					e.printStackTrace();
				}
			}
			// Chiusura dell connection
			if (conn != null) {
				try {
					conn.close();
					conn = null;
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura Connection");
					e.printStackTrace();
				}
			}

		}

	}

	public static void refactorStudenteByMatricola(String matricolaDaAggiornare, String nuovoNome, String nuovoCognome,
			int nuovaEta, String nuovaDataDiNascita, String nuovoNomeCorso) {
		Connection conn = null;
		PreparedStatement stmt = null;

		String url = "jdbc:mysql://localhost:3306/studenti";
		String username = "root";
		String password = "";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, username, password);

			String updateQuery = "UPDATE studenti SET nome = ?, cognome = ?, eta = ?, data_di_nascita = ?, nome_corso = ? WHERE matricola = ?";

			stmt = conn.prepareStatement(updateQuery);

			stmt.setString(1, nuovoNome);
			stmt.setString(2, nuovoCognome);
			stmt.setInt(3, nuovaEta);
			stmt.setString(4, nuovaDataDiNascita);
			stmt.setString(5, nuovoNomeCorso);
			stmt.setString(6, matricolaDaAggiornare);

			stmt.executeUpdate();

		} catch (ClassNotFoundException e) {
			System.out.println("Classe non trovata");
			e.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Eccezione specifica di SQL");
			sql.printStackTrace();
		} catch (Exception e) {
			System.out.println("Eccezione generica");
			e.printStackTrace();
		} finally {

			if (stmt != null) {
				try {
					stmt.close();
					stmt = null;
				} catch (SQLException e) {
					System.out.println("Errore di chiusura Statement");
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
					conn = null;
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura Connection");
					e.printStackTrace();
				}

			}
		}
	}

	public static void refactorStudenteByNomeCognome(String nomeDaAggiornare, String cognomeDaAggiornare, int nuovaEta,
			String nuovaDataDiNascita, String nuovoNomeCorso) {

		Connection conn = null;
		PreparedStatement stmt = null;

		String url = "jdbc:mysql://localhost:3306/studenti";
		String username = "root";
		String password = "";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, username, password);

			String updateQuery = "UPDATE studenti SET eta = ?, data_di_nascita = ?, nome_corso = ? WHERE nome = ? AND cognome = ?";

			stmt = conn.prepareStatement(updateQuery);

			stmt.setInt(1, nuovaEta);
			stmt.setString(2, nuovaDataDiNascita);
			stmt.setString(3, nuovoNomeCorso);
			stmt.setString(4, nomeDaAggiornare);

			stmt.executeUpdate();

		} catch (ClassNotFoundException e) {
			System.out.println("Classe non trovata");
			e.printStackTrace();
		} catch (SQLException sql) {
			System.out.println("Eccezione specifica di SQL");
			sql.printStackTrace();
		} catch (Exception e) {
			System.out.println("Eccezione generica");
			e.printStackTrace();
		}  finally {

			if (stmt != null) {
				try {
					stmt.close();
					stmt = null;
				} catch (SQLException e) {
					System.out.println("Errore di chiusura Statement");
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
					conn = null;
				} catch (SQLException e) {
					System.out.println("Problemi di chiusura Connection");
					e.printStackTrace();
				}

			}
		}

	}

}

package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import configuration.HibernateUtil;
import entity.Partita;

public class PartitaDaoImpl implements InterfacciaDao{

	@Override
	public <Partita> void save(Partita tipo) {
		Transaction transaction = null;
		Session session = null;
		
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
				
			session.save(tipo);
			
			transaction.commit();
			
		}catch(HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
			
		}catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}finally {
			session.close();
		}
		
	}

	@Override
	public <Partita> List<Partita> getAll() {
		List<Partita> listaPartita = new ArrayList<>();
		Session session = null;

		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();

			//SeCreatiDaJavaLaTabella il nome PerLaQuery deve avere laSintassiJAVA
			listaPartita = session.createQuery("FROM Partita").list();
			
			for(Partita citta:listaPartita) {
				System.out.println(citta);
			}


			
			
		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}finally {
			session.close();
		}
		return listaPartita;
	}

	@Override
	public <Partita> Partita getOne(Object pk) {
		Partita partita = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			Query<Partita> query = session.createQuery("SELECT p FROM Partita p WHERE p.id = :id");
			query.setParameter("id", pk);
			partita = query.getSingleResult();
			System.out.println(partita);
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
			
		return partita;
	}

	@Override
	public void deleteOne(Object pk) {
		Partita capitano = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Partita> query = session.createQuery("DELETE FROM Partita p WHERE p.id = :id");
			query.setParameter("id", pk);
			query.executeUpdate(); // Esegue l'eliminazione e restituisce il numero di righe modificate

			// Commit della transazione
			transaction.commit();
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
		
	}


	public void aggiornaData(int pk, String nuovaData) {
		Transaction transaction = null;
		Session session = null;
		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			// Trovo la persona nel database
			Partita aggiornaDataPartita = session.find(Partita.class, pk);

			// cambio il nome della persona trovata
			aggiornaDataPartita.setData(nuovaData);;
			
			transaction.commit();

			session.close();
		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}
		
	}

}

package dao;

import java.util.List;

public interface InterfacciaDao {
	public <T >void save(T tipo);
	
	public <T> List<T> getAll();
	
	public <T> T getOne(Object pk);
	
	public void deleteOne(Object pk);
}

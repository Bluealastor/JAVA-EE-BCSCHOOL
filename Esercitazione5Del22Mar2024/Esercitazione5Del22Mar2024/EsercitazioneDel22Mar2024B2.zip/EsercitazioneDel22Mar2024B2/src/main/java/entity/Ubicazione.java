package entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Ubicazione {
	
	@Column
	private String indirizzo;
	
	@Column
	private String citta;
	
	@Column
	int cap;
	
	public Ubicazione() {
		super();
	}

	public Ubicazione(String indirizzo, String citta, int cap) {
		super();
		this.indirizzo = indirizzo;
		this.citta = citta;
		this.cap = cap;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getCitta() {
		return citta;
	}

	public void setCitta(String citta) {
		this.citta = citta;
	}

	public int getCap() {
		return cap;
	}

	public void setCap(int cap) {
		this.cap = cap;
	}

	@Override
	public String toString() {
		return "Ubicazione [indirizzo=" + indirizzo + ", citta=" + citta + ", cap=" + cap + "]";
	}

	
}

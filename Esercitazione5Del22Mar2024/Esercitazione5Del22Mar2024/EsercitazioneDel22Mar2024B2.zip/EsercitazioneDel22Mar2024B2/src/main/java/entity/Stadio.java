package entity;


import entity.Partita;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table
public class Stadio {

	@Id
	@Column(name = "nome")
	private String nome;
	
	@Column
	private int capienza;
	
	@Column
	private String tipo;
	
	@Embedded
	private Ubicazione ubicazione;
	
	@OneToMany(mappedBy = "stadio")
	private List<Partita> partita;

	public Stadio() {
		super();
	}
	

	public Stadio(String nome, int capienza, String tipo, Ubicazione ubicazione) {
		super();
		this.nome = nome;
		this.capienza = capienza;
		this.tipo = tipo;
		this.ubicazione = ubicazione;
	}




	public Stadio(String nome, int capienza, String tipo, Ubicazione ubicazione, List<Partita> partita) {
		super();
		this.nome = nome;
		this.capienza = capienza;
		this.tipo = tipo;
		this.ubicazione = ubicazione;
		this.partita = partita;
	}








	public String getNoem() {
		return nome;
	}

	public void setNoem(String nome) {
		this.nome = nome;
	}

	public int getCapienza() {
		return capienza;
	}

	public void setCapienza(int capienza) {
		this.capienza = capienza;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "Stadio [noem=" + nome + ", capienza=" + capienza + ", tipo=" + tipo + "]";
	}
	
	
	
	
	
	
}

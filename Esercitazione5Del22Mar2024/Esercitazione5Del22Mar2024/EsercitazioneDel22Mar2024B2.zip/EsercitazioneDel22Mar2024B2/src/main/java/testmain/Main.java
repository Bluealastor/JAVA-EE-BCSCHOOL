package testmain;

import java.util.ArrayList;
import java.util.List;

import dao.InterfacciaDao;
import dao.PartitaDaoImpl;
import dao.StadioDaoImpl;
import entity.Partita;
import entity.Stadio;
import entity.Ubicazione;

public class Main {

	public static void main(String[] args) {
		
		InterfacciaDao partitaDao = new PartitaDaoImpl();
		InterfacciaDao stadioDao = new StadioDaoImpl();
		
		Partita partita = new Partita("22-02-2023", "Montagna", "Palermo", "Catania");
		Ubicazione ubicazione = new Ubicazione("Indirizzo", "Palermo", 6579);
		Stadio stadio = new Stadio("Renzo Barbera", 100, "calcio", ubicazione);
		
		partita.setStadio(stadio);
		stadioDao.save(stadio);
		partitaDao.save(partita);
		

	}

}

package test;

import entity.Personaggio;
import entity.Videogioco;

import java.util.ArrayList;
import java.util.List;

import dao.InterfacciaDao;
import dao.VideogiocoDaoImpl;
import dao.PersonaggioDaoImpl;

public class Main {

	public static void main(String[] args) {
		InterfacciaDao videogiocoDao = new VideogiocoDaoImpl();
		InterfacciaDao personaggioDao = new PersonaggioDaoImpl();
		
		
		
		Videogioco videogioco1 = new Videogioco("Assassin Creed", "Open Wolrd", "Assassini vs Templari", 18);
		Personaggio personaggio1 = new Personaggio("Ezio", 20, "Lama Celata", "Assassini","Umano", videogioco1);
		List<Personaggio> listaPersonaggio = new ArrayList<>();
		listaPersonaggio.add(personaggio1);
		videogioco1.setPersonaggio(listaPersonaggio);
		videogiocoDao.save(videogioco1);
		
		personaggioDao.save(personaggio1);

	}

}

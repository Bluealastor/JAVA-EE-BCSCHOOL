package dao;

import java.util.List;

public interface InterfacciaDao {
	
	public <T >void save(T tipo);
	
	public <T> List<T> getAll();
	
	public <T> T getOne(int pk);
	
	public void deleteOne(int pk);
	
	public void aggiornaName(int pk, String nuovoNome);

}

package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import configuration.HibernateUtil;
import entity.Personaggio;

public class PersonaggioDaoImpl implements InterfacciaDao{

	@Override
	public <Personaggio> void save(Personaggio tipo) {
		Transaction transaction = null;
		Session session = null;
		
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
				
			session.save(tipo);
			
			transaction.commit();
			
		}catch(HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
			
		}catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}finally {
			session.close();
		}
		
	}

	@Override
	public <Personaggio> List<Personaggio> getAll() {
		List<Personaggio> listaPersonaggio = new ArrayList<>();
		Session session = null;

		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();

			//SeCreatiDaJavaLaTabella il nome PerLaQuery deve avere laSintassiJAVA
			listaPersonaggio = session.createQuery("FROM Personaggio").list();
			
			for(Personaggio personaggio :listaPersonaggio) {
				System.out.println(personaggio);
			}


			
			
		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}finally {
			session.close();
		}
		return listaPersonaggio;
	}

	@Override
	public <Personaggio> Personaggio getOne(int pk) {
		Personaggio personaggio = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			Query<Personaggio> query = session.createQuery("SELECT p FROM Personaggio p WHERE p.id = :id");
			query.setParameter("id", pk);
			personaggio = query.getSingleResult();
			System.out.println(personaggio);
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
			
		return personaggio;
	}

	@Override
	public void deleteOne(int pk) {
		Personaggio personaggio = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Personaggio> query = session.createQuery("DELETE FROM Personaggio p WHERE p.id = :id");
			query.setParameter("id", pk);
			query.executeUpdate(); // Esegue l'eliminazione e restituisce il numero di righe modificate

			// Commit della transazione
			transaction.commit();
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
		
	}

	@Override
	public void aggiornaName(int pk, String nuovoNome) {
		Transaction transaction = null;
		Session session = null;
		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			// Trovo la persona nel database
			Personaggio aggiornaNomePersonaggio = session.find(Personaggio.class, pk);

			// cambio il nome della persona trovata
			aggiornaNomePersonaggio.setNome(nuovoNome);;
			
			transaction.commit();

			session.close();
		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}
		
	}

	
	

}

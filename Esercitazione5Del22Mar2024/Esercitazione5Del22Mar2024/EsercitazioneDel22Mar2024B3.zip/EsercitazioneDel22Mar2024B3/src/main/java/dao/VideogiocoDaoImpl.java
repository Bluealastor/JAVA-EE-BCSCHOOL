package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import configuration.HibernateUtil;
import entity.Videogioco;

public class VideogiocoDaoImpl implements InterfacciaDao{

	@Override
	public <Videogioco> void save(Videogioco tipo) {
		Transaction transaction = null;
		Session session = null;
		
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
				
			session.save(tipo);
			
			transaction.commit();
			
		}catch(HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
			
		}catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}finally {
			session.close();
		}
		
	}

	@Override
	public <Videogioco> List<Videogioco> getAll() {
		List<Videogioco> listaVideogioco = new ArrayList<>();
		Session session = null;

		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();

			//SeCreatiDaJavaLaTabella il nome PerLaQuery deve avere laSintassiJAVA
			listaVideogioco = session.createQuery("FROM Videogioco").list();
			
			for(Videogioco videogioco:listaVideogioco) {
				System.out.println(videogioco);
			}


			
			
		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}finally {
			session.close();
		}
		return listaVideogioco;
	}

	@Override
	public <Videogioco> Videogioco getOne(int pk) {
		Videogioco videogioco = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			Query<Videogioco> query = session.createQuery("SELECT v FROM Videogioco v WHERE v.id = :id");
			query.setParameter("id", pk);
			videogioco = query.getSingleResult();
			System.out.println(videogioco);
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
			
		return videogioco;
	}

	@Override
	public void deleteOne(int pk) {
		Videogioco videogioco = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Videogioco> query = session.createQuery("DELETE FROM Videogioco v WHERE v.id = :id");
			query.setParameter("id", pk);
			query.executeUpdate(); // Esegue l'eliminazione e restituisce il numero di righe modificate

			// Commit della transazione
			transaction.commit();
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
		
	}

	@Override
	public void aggiornaName(int pk, String nuovoNome) {

		Transaction transaction = null;
		Session session = null;
		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			// Trovo la persona nel database
			Videogioco aggiornaNomeVideogioco = session.find(Videogioco.class, pk);

			// cambio il nome della persona trovata
			aggiornaNomeVideogioco.setNome(nuovoNome);;
			
			transaction.commit();

			session.close();
		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}
		
	}

}

package entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@SecondaryTable(name = "dettagli_personaggio", pkJoinColumns = @PrimaryKeyJoinColumn(name = "id_personaggio"))
@Table
public class Personaggio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column
	private String nome;
	
	@Column
	private int eta;
	
	@Column(name = "inventario", table = "dettagli_personaggio")
	private String inventario;
	
	@Column(name = "fazione", table = "dettagli_personaggio")
	private String fazione;
	
	@Column(name = "razza", table = "dettagli_personaggio")
	private String razza;
	
	@ManyToOne
	@JoinColumn(name= "idGioco", referencedColumnName = "id")
	private Videogioco videogioco;

	public Personaggio() {
		super();
	}
	
	public Personaggio(String nome, int eta, String inventario, String fazione, String razza) {
		super();
		this.nome = nome;
		this.eta = eta;
		this.inventario = inventario;
		this.fazione = fazione;
		this.razza = razza;
	}

	public Personaggio(String nome, int eta, String inventario, String fazione, String razza, Videogioco videogioco) {
		super();
		this.nome = nome;
		this.eta = eta;
		this.inventario = inventario;
		this.fazione = fazione;
		this.razza = razza;
		this.videogioco = videogioco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getEta() {
		return eta;
	}

	public void setEta(int eta) {
		this.eta = eta;
	}

	public String getInventario() {
		return inventario;
	}

	public void setInventario(String inventario) {
		this.inventario = inventario;
	}

	public String getFazione() {
		return fazione;
	}

	public void setFazione(String fazione) {
		this.fazione = fazione;
	}

	public String getRazza() {
		return razza;
	}

	public void setRazza(String razza) {
		this.razza = razza;
	}

	public Videogioco getVideogioco() {
		return videogioco;
	}

	public void setVideogioco(Videogioco videogioco) {
		this.videogioco = videogioco;
	}

	@Override
	public String toString() {
		return "Personaggio [id=" + id + ", nome=" + nome + ", eta=" + eta + ", inventario=" + inventario + ", fazione="
				+ fazione + ", razza=" + razza + ", videogioco=" + videogioco + "]";
	}
	
	
	
	

}

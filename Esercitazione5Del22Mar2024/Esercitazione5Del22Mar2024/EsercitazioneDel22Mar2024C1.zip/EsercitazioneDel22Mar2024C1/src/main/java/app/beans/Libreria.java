package app.beans;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;

public class Libreria {
	
	private String nome;
	
	@Autowired
	private Romanzo romanzo;
	
	@Lazy
	@Autowired
	private Saggio saggio;
	
	public Libreria() {
		super();
	}

	public Libreria(String nome) {
		super();
		this.nome = nome;
	}

	public Libreria(Romanzo romanzo) {
		this.romanzo = romanzo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@PostConstruct
	public void welcom() {
		System.out.println("Benvenuto In libreria");
	}
	
	public String readBook() {
		return "sei nella libreria " +this.nome +" Cosa Vuoi Leggere?";
	}

}

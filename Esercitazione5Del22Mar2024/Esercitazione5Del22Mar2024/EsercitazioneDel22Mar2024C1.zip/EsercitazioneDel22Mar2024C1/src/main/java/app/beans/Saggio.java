package app.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

public class Saggio {
	
	private String nomeSaggio;
	
	private Libreria libreria;

	public String getNomeSaggio() {
		return nomeSaggio;
	}

	public void setNomeSaggio(String nomeSaggio) {
		this.nomeSaggio = nomeSaggio;
	}
	
	@PostConstruct
	public void scelta() {
		System.out.println("solo in pochi leggono i saggi ed è lazy");
	}
	
	@PreDestroy
	public void predestruct() {
		System.out.println("Solo in pochi finiscono un saggio poco prima della cancellazione del dato");
	}

}

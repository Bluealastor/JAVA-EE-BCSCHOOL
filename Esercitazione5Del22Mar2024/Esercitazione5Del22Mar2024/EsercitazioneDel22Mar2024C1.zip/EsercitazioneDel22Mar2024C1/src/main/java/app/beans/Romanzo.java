package app.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

public class Romanzo {
	
	private String nomeRomanzo;
	
	private Libreria libreria;

	public Romanzo() {
		super();
	}
	
	

	public Romanzo(String nomeRomanzo) {
		super();
		this.nomeRomanzo = nomeRomanzo;
	}



	public String getNomeRomanzo() {
		return nomeRomanzo;
	}

	public void setNomeRomanzo(String nomeRomanzo) {
		this.nomeRomanzo = nomeRomanzo;
	}
	@PostConstruct
	public void welcom() {
		System.out.println("bel romanzo prima della modifica del nome di default " + this.nomeRomanzo);
	}
	
	@PreDestroy
	public void predestruct() {
		System.out.println("poco prima della distruzione del dato Romanzo");
	}


}

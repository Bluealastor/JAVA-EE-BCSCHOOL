package app;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Lazy;

import app.beans.Libreria;
import app.beans.Romanzo;
import app.beans.Saggio;
import app.configuration.Config;

public class Main {
	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(Config.class);

		Libreria lib1 = context.getBean(Libreria.class);
		Romanzo rom1 = context.getBean("romanticismo",Romanzo.class);
		Romanzo rom2 = context.getBean("romanzo",Romanzo.class);
		
		lib1.setNome("Manzone");
		System.out.println(lib1.readBook());
		System.out.println(rom1.getNomeRomanzo());
		System.out.println(lib1.readBook());
		System.out.println(rom2.getNomeRomanzo());
		System.out.println();
		Saggio sag1 = context.getBean(Saggio.class);
		context.close();
	}
}

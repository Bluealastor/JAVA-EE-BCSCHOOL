package app.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import app.beans.Libreria;
import app.beans.Romanzo;
import app.beans.Saggio;

@Configuration
public class Config {
	
	@Bean
	public Libreria libreria() {
		return new Libreria();
	}
	
	@Bean(name = "romanzo")
	public Romanzo romanzo() {
		return new Romanzo("Promessi Sposi");
	}
	
	@Bean(name = "romanticismo")
	public Romanzo romanzo2() {
		return new Romanzo("Sul romanticismo");
	}

	@Lazy
	@Bean(name = "saggio")
	public Saggio saggio() {
		return new Saggio();
	}
}

package testmain;

import entity.Capitano;
import entity.Nave;

import dao.InterfacciaDao;
import dao.NaveDaoImpl;
import dao.CapitanoDaoImpl;

public class Main {

	public static void main(String[] args) {
		InterfacciaDao capitanoDao = new CapitanoDaoImpl();
		InterfacciaDao naveDao = new NaveDaoImpl();
		
		Capitano capitano = new Capitano("Sparrow");
		Nave nave = new Nave("Perla Nera","Vela", 5, capitano);
		
		Capitano capitano1 = new Capitano("Sparrow");
		
		capitanoDao.save(capitano);
		capitanoDao.save(capitano1);
		naveDao.save(nave);
		
		capitanoDao.getAll();
		naveDao.getAll();
		
		capitanoDao.aggiornaName(1, "Roger");
		naveDao.aggiornaName(1, "Roger");
		
		capitanoDao.getAll();
		naveDao.getAll();
		
		capitanoDao.deleteOne(2);
		capitanoDao.getAll();
		
		naveDao.deleteOne(2);
		naveDao.getAll();
		
	}

}

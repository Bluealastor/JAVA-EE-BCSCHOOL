package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import configuration.HibernateUtil;
import entity.Nave;

public class NaveDaoImpl implements InterfacciaDao{

	@Override
	public <Nave> void save(Nave tipo) {
		Transaction transaction = null;
		Session session = null;
		
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
				
			session.save(tipo);
			
			transaction.commit();
			
		}catch(HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
			
		}catch(Exception e) {
			e.printStackTrace();
			transaction.rollback();
		}finally {
			session.close();
		}
		
	}

	@Override
	public <Nave> List<Nave> getAll() {
		List<Nave> listaNave = new ArrayList<>();
		Session session = null;

		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();

			//SeCreatiDaJavaLaTabella il nome PerLaQuery deve avere laSintassiJAVA
			listaNave = session.createQuery("FROM Nave").list();
			
			for(Nave nave:listaNave) {
				System.out.println(nave);
			}

		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}finally {
			session.close();
		}
		return listaNave;
	}

	@Override
	public <Nave> Nave getOne(int pk) {
		Nave nave = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Nave> query = session.createQuery("SELECT n FROM Nave n WHERE n.codice = :codice");
			query.setParameter("codice", pk);
			nave = query.getSingleResult();
			System.out.println(nave);
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
			
		return nave;
	}

	@Override
	public void deleteOne(int pk) {
		Nave nave = null;

		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			// RICORDARSI SI DARE UN SOPRANNOME ALLA TABELLA NON ACCETA *
			Query<Nave> query = session.createQuery("DELETE FROM Nave n WHERE n.codice = :codice");
			query.setParameter("codice", pk);
			query.executeUpdate(); 
			transaction.commit();
			session.close();
			
			}catch(HibernateException e) {
				System.out.println("Problema Hibernate GetONE Corso");
				e.printStackTrace();
			}catch(Exception e) {
				System.out.println("Problema generico per la GettONE Corso");
				e.printStackTrace();
			}
	}

	@Override
	public void aggiornaName(int pk, String nuovoNome) {

		Transaction transaction = null;
		Session session = null;
		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			// Trovo la persona nel database
			Nave aggiornaNomeNave = session.find(Nave.class, pk);

			// cambio il nome della persona trovata
			aggiornaNomeNave.setNome(nuovoNome);;
			
			transaction.commit();

			session.close();
		} catch (HibernateException hibernateException) {
			System.out.println("Eccezione specifica di Hibernate durante la query");
			hibernateException.printStackTrace();

		} catch (Exception e) {
			System.out.println("Eccezione generica durante la query");
			e.printStackTrace();

		}
		
	}

}

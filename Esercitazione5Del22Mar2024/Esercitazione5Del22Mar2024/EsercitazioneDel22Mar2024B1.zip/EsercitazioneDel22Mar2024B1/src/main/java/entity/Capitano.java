package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class Capitano {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column
	private String nome;
	
	@OneToOne
	private Nave idNave;
	

	public Capitano() {
		super();
	}

	public Capitano(String nome) {
		super();
		this.nome = nome;
	}

	public Capitano(String nome, Nave idNave) {
		super();
		this.nome = nome;
		this.idNave = idNave;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	
	public Nave getIdNave() {
		return idNave;
	}

	public void setIdNave(Nave idNave) {
		this.idNave = idNave;
	}

	@Override
	public String toString() {
		return "Capitano [id=" + id + ", nome=" + nome + "]";
	}
	
	
	
	
	
}

package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class Nave {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int codice;
	
	@Column
	private String nome;
	
	@Column
	private String propulsione;
	
	@Column
	private int nScialuppe;
	
	@OneToOne(mappedBy = "idNave")
	@JoinColumn(name = "IdCapitano")
	private Capitano capitano;
	
	public Nave() {
		super();
	}
	
	public Nave(Capitano capitano) {
		super();
		this.capitano = capitano;
	}



	public Nave(int codice, String nome, String propulsione, int nScialuppe, Capitano capitano) {
		super();
		this.codice = codice;
		this.nome = nome;
		this.propulsione = propulsione;
		this.nScialuppe = nScialuppe;
		this.capitano = capitano;
	}
	
	public Nave(String nome, String propulsione, int nScialuppe, Capitano capitano) {
		super();
		this.nome = nome;
		this.propulsione = propulsione;
		this.nScialuppe = nScialuppe;
		this.capitano = capitano;
	}
	
	
	

	public int getCodice() {
		return codice;
	}


	public void setCodice(int codice) {
		this.codice = codice;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getPropulsione() {
		return propulsione;
	}


	public void setPropulsione(String propulsione) {
		this.propulsione = propulsione;
	}


	public int getnScialuppe() {
		return nScialuppe;
	}


	public void setnScialuppe(int nScialuppe) {
		this.nScialuppe = nScialuppe;
	}


	@Override
	public String toString() {
		return "Nave [codice=" + codice + ", nome=" + nome + ", propulsione=" + propulsione + ", nScialuppe="
				+ nScialuppe + "]";
	}
	
	
	
	

}
